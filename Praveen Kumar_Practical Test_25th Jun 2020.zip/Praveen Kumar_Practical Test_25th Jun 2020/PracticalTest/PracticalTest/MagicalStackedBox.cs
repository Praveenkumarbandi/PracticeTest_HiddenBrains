﻿using System;


/*
 When you open a Magical Stacked Box, you find a smaller Magical Stacked Box inside it and a smaller Magical Stacked Box inside that.
 The smallest Magical Stacked Box has no boxes inside it.

 Modidy Magical Stacked Box.NumberOfSmallerBoxes so that it returns, *efficiently* with respect to time used,
 the total number of Magical Stacked Boxes that contained inside that instance of the box.

 For example, new MagicalStackedBox(new MagicalStackedBox()).NumberOfSmallerBoxes should return 1, 
 because the outer box contains only 1 box.
*/

public class MagicalStackedBox
{
    public static int count = 0;
    private readonly MagicalStackedBox containedBox;

    public MagicalStackedBox()
    {
        count = count + 1;
    }

    public MagicalStackedBox(MagicalStackedBox containedBox)
    {
        this.containedBox = containedBox;
    }

    public int NumberOfSmallerBoxes
    {
        get
        {
            return MagicalStackedBox.count;
        }
    }

    public static void Main(string[] args)
    {
        Console.WriteLine(new MagicalStackedBox(new MagicalStackedBox()).NumberOfSmallerBoxes);
        Console.ReadLine();
    }
}