﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

/*
 Given a data structure representing a social network.
 Implement method CanBeConnected on class Friend.

 The method should check if a connection to the given member exists, *efficiently* with respect to time used.
 That should be either a direct friendship or a chain of members between them who are mutual friends.

 For example, 
 1. if A and B are friends and B and C are friends, then A.CanBeConnected(C) should return true,
 since, C is a friend of B and B is a friend of A.

 2. if A and B are friends, B and C are friends and C and D are friends, then A.CanBeConnected(D) should return true,
 since, D is a friend of C, C is a friend of B and B is a friend of A.
*/

public class Friend
{
    public string Name { get; private set; }

    public ICollection<Friend> Friends { get; private set; }

    public Friend(string name)
    {
        this.Name = name;
        this.Friends = new List<Friend>();
    }

    public void AddFriendship(Friend friend)
    {
        this.Friends.Add(friend);
        friend.Friends.Add(this);
    }

    public bool CanBeConnected(Friend friend)
    {
        bool result = false;
        try
        {
            List<Friend> lstFriend = new List<Friend>();
            lstFriend = this.Friends.ToList();

            if (lstFriend.Count > 0)
                foreach (Friend eachfrnd in lstFriend)
                {
                    List<Friend> lstFriendOfFriends = new List<Friend>();
                    lstFriendOfFriends = eachfrnd.Friends.ToList();

                    //if (eachfrnd.Name == friend.Name)
                    //    result = true;

                    foreach (Friend eachFriendOfFriend in eachfrnd.Friends)
                    {
                        if (eachFriendOfFriend.Name == friend.Name)
                        {
                            result = true;
                        }
                    }
                }
        }
        catch (Exception ex)
        {
            result = false;
            MessageBox.Show(ex.ToString());
        }
        return result;
    }

    public static void Main(string[] args)
    {
        Friend a = new Friend("A");
        Friend b = new Friend("B");
        Friend c = new Friend("C");
        Friend d = new Friend("D");

        a.AddFriendship(b);
        b.AddFriendship(c);
        c.AddFriendship(d); 

        Console.WriteLine(a.CanBeConnected(c));
        Console.WriteLine(a.CanBeConnected(d));

        Console.ReadLine();
    }
}
