﻿using System;


/*
 An building tower is being divided up and converted into apartments. 
 A Large apartment takes up 2 floors of the building, and a Small apartment takes up 1 floor.

 Write a function that, takes value of the number of floors in the building, 
 and calculates the Number of different possible arrangements of apartments.

 For example, 
 if the building has 3 floors then it can provide 3 diffrent possible arrangements of apartments: 
  - small-small-small, small-large and large-small.
*/

public class Apartments
{
    public static int NumberOfArrangements(int numberOfFloors)
    {
        throw new NotImplementedException("waiting to be implemented.");
    }

    public static void Main(string[] args)
    {
        Console.WriteLine(NumberOfArrangements(3));
        ////Console.WriteLine(NumberOfArrangements(4));

        Console.ReadLine();
    }
}