﻿using System;
using System.Collections.Generic;
using System.Linq;

/*
    Program below do not show correct result for distinct Employee count.
    Update Employee class so that it shows correct result.

    For example, 
    Distinct Employee should be 2 not 4 in given problem.
*/

public class Employee
{
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public static int FindDistinctEmployeeCount(List<Employee> lstEmployee)
    {
        //return lstEmployee.Distinct().Count();
        return lstEmployee.GroupBy(obj => new { obj.FirstName, obj.LastName }).Select(obj => obj.First()).Count();
    }

    public static void Main(string[] args)
    {
        var lstEmployee = new List<Employee>(){
                new Employee(){ FirstName = "A", LastName = "A"},
                new Employee(){ FirstName = "B", LastName = "B"},
                new Employee(){ FirstName = "A", LastName = "A"},
                new Employee(){ FirstName = "B", LastName = "B"}
            };

        Console.WriteLine(FindDistinctEmployeeCount(lstEmployee));
        Console.ReadKey();
    }
}