﻿using System;
using System.Linq;

/*
 Write a method that, efficiently with respect to time used, finds the n-th lowest selling book in the list.
 Each element of the sales array represents a single sale of a book with that books id. The n-th lowest
 selling book is the book that has more sales than n-1 books. If multiple books share the n-th lowest selling
 spot, the method can return any one of them.

 For example, NthLowestSelling(new int[](5,4,3,2,1,5,4,3,2,5,4,3,5,4,5),2) should return 2.
 In the array, the book with the Id 1 was sold once, Id 2 twice, Id 3 three times. Id 4 four times, and
 Id 5 five times, making the book with the Id 1 the lowest selling book in the array and Id 2 the second lowest
 selling book.
*/

public class BookSale
{
    public static int NthLowestSelling(int[] sales, int n)
    {
        int salescount = 0;

        foreach (var eachsale in sales.GroupBy(obj => obj))
            if (eachsale.Key.Equals(n))
            {
                salescount = eachsale.Count();
                break;
            }

        return salescount;
    }

    private static bool ContainDuplicatedValue(int[] values)
    {
        var duplicates = values.GroupBy(p => p).Where(g => g.Count() > 1).Select(g => g.Key);
        return (duplicates.Count() > 0);
    }

    public static void Main(string[] args)
    {
        int[] values = new int[] { 1, 2, 0 };
        bool result = false;
        result = ContainDuplicatedValue(values);

        Console.WriteLine("Enter Book number:");
        int x = NthLowestSelling(new int[] { 5, 4, 3, 2, 1, 5, 4, 3, 2, 5, 4, 3, 5, 4, 5 }, Convert.ToInt32(Console.ReadLine()));
        Console.WriteLine(x);
        Console.ReadLine();
    }
}